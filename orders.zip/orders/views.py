from decimal import Decimal, InvalidOperation

import razorpay

from django.conf import settings
from django.db import transaction
from django.shortcuts import get_object_or_404

from rest_framework import generics, permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import Cart, CartItem, Order, OrderItem
from .serializers import CartSerializer, OrderSerializer
from store.models import Product, ProductVariant


def get_razorpay_client():
    return razorpay.Client(
        auth=(
            settings.RAZORPAY_KEY_ID,
            settings.RAZORPAY_KEY_SECRET,
        )
    )


class CartView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        cart, _ = Cart.objects.get_or_create(user=request.user)
        return Response(CartSerializer(cart).data)

    def post(self, request):
        product_id = request.data.get("product_id")
        variant_id = request.data.get("variant_id")
        quantity = request.data.get("quantity", 1)

        try:
            quantity = int(quantity)
            if quantity < 1:
                raise ValueError
        except (TypeError, ValueError):
            return Response(
                {"error": "Quantity must be a positive integer."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        product = get_object_or_404(
            Product,
            id=product_id,
            is_active=True,
        )

        variant = None
        if variant_id:
            variant = get_object_or_404(
                ProductVariant,
                id=variant_id,
                product=product,
            )
            if variant.stock < quantity:
                return Response(
                    {"error": "Not enough stock for the selected size."},
                    status=status.HTTP_400_BAD_REQUEST,
                )
        elif product.variants.exists():
            return Response(
                {"error": "Please select a size."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        elif product.stock < quantity:
            return Response(
                {"error": "Not enough stock available."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        cart, _ = Cart.objects.get_or_create(user=request.user)

        item, created = CartItem.objects.get_or_create(
            cart=cart,
            product=product,
            variant=variant,
            defaults={"quantity": quantity},
        )

        if not created:
            item.quantity += quantity

            available_stock = (
                variant.stock if variant else product.stock
            )

            if item.quantity > available_stock:
                return Response(
                    {"error": "Requested quantity exceeds available stock."},
                    status=status.HTTP_400_BAD_REQUEST,
                )

            item.save(update_fields=["quantity"])

        return Response(
            CartSerializer(cart).data,
            status=status.HTTP_201_CREATED,
        )

    def delete(self, request):
        item_id = request.data.get("item_id")

        CartItem.objects.filter(
            id=item_id,
            cart__user=request.user,
        ).delete()

        cart, _ = Cart.objects.get_or_create(user=request.user)
        return Response(CartSerializer(cart).data)


class OrderListCreateView(generics.ListCreateAPIView):
    serializer_class = OrderSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_serializer_context(self):
        context = super().get_serializer_context()
        context["request"] = self.request
        return context

    def get_queryset(self):
        return Order.objects.filter(
            user=self.request.user
        ).order_by("-created_at")

    def create(self, request, *args, **kwargs):
        """
        Accept a checkout only after verifying the Razorpay checkout
        signature. Prices and stock are taken from the database.

        Required payment fields:
          razorpay_order_id
          razorpay_payment_id
          razorpay_signature

        This endpoint must receive a Razorpay order ID created by
        your trusted backend, with an amount matching the server total.
        """
        razorpay_order_id = request.data.get("razorpay_order_id")
        razorpay_payment_id = request.data.get("razorpay_payment_id")
        razorpay_signature = request.data.get("razorpay_signature")
        items_data = request.data.get("items", [])

        if not all([
            razorpay_order_id,
            razorpay_payment_id,
            razorpay_signature,
        ]):
            return Response(
                {"error": "Required Razorpay payment details are missing."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        if not isinstance(items_data, list) or not items_data:
            return Response(
                {"error": "Your order must contain at least one item."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        client = get_razorpay_client()

        try:
            client.utility.verify_payment_signature({
                "razorpay_order_id": razorpay_order_id,
                "razorpay_payment_id": razorpay_payment_id,
                "razorpay_signature": razorpay_signature,
            })

            # Verify payment status with Razorpay as well.
            payment = client.payment.fetch(razorpay_payment_id)

            if payment.get("order_id") != razorpay_order_id:
                raise ValueError("Payment does not match the order.")

            if payment.get("status") != "captured":
                return Response(
                    {"error": "Payment has not been captured."},
                    status=status.HTTP_400_BAD_REQUEST,
                )

        except Exception:
            return Response(
                {"error": "Payment verification failed."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        try:
            with transaction.atomic():
                # Prevent a successful payment from creating duplicate
                # orders when the same payment is submitted again.
                if Order.objects.filter(
                    razorpay_order_id=razorpay_order_id
                ).exists():
                    return Response(
                        {"error": "This payment has already been processed."},
                        status=status.HTTP_409_CONFLICT,
                    )

                validated_items = []
                subtotal = Decimal("0.00")

                for item in items_data:
                    product_id = item.get("product_id")
                    variant_id = item.get("variant_id")
                    size = str(item.get("size", "")).strip()
                    color = str(item.get("color", "")).strip()

                    try:
                        quantity = int(item.get("quantity", 1))
                        if quantity < 1:
                            raise ValueError
                    except (TypeError, ValueError):
                        return Response(
                            {"error": "Each quantity must be a positive integer."},
                            status=status.HTTP_400_BAD_REQUEST,
                        )

                    product = Product.objects.select_for_update().filter(
                        id=product_id,
                        is_active=True,
                    ).first()

                    if not product:
                        return Response(
                            {"error": "A product is unavailable."},
                            status=status.HTTP_400_BAD_REQUEST,
                        )

                    variant = None

                    if variant_id:
                        variant = ProductVariant.objects.select_for_update().filter(
                            id=variant_id,
                            product=product,
                        ).first()
                    elif size:
                        variant = ProductVariant.objects.select_for_update().filter(
                            product=product,
                            size=size,
                            color=color,
                        ).first()

                    if product.variants.exists():
                        if not variant:
                            return Response(
                                {
                                    "error": (
                                        f"Please select a valid size for "
                                        f"{product.name}."
                                    )
                                },
                                status=status.HTTP_400_BAD_REQUEST,
                            )

                        if variant.stock < quantity:
                            return Response(
                                {
                                    "error": (
                                        f"Insufficient stock for "
                                        f"{product.name}, size {variant.size}."
                                    )
                                },
                                status=status.HTTP_400_BAD_REQUEST,
                            )

                        size = variant.size
                        color = variant.color or color
                    else:
                        if product.stock < quantity:
                            return Response(
                                {
                                    "error": (
                                        f"Insufficient stock for {product.name}."
                                    )
                                },
                                status=status.HTTP_400_BAD_REQUEST,
                            )

                    price = Decimal(str(product.price))
                    subtotal += price * quantity

                    validated_items.append({
                        "product": product,
                        "variant": variant,
                        "quantity": quantity,
                        "price": price,
                        "size": size,
                        "color": color,
                    })

                # Important: compare this server-calculated total and
                # shipping charge against the amount used to create
                # the Razorpay order. Do not trust client totals.
                #
                # Your checkout flow must provide a server-created
                # Razorpay order whose amount equals this calculation
                # plus the server-calculated shipping charge.
                shipping_charge = Decimal("0.00")
                total = subtotal + shipping_charge

                expected_paise = int(total * 100)
                if int(payment.get("amount", -1)) != expected_paise:
                    return Response(
                        {
                            "error": (
                                "The paid amount does not match the "
                                "server-calculated order total."
                            )
                        },
                        status=status.HTTP_400_BAD_REQUEST,
                    )

                serializer = self.get_serializer(data=request.data)
                serializer.is_valid(raise_exception=True)

                order = serializer.save(
                    user=request.user,
                    status="confirmed",
                    razorpay_order_id=razorpay_order_id,
                )

                # Never trust product names or prices from the frontend.
                for item in validated_items:
                    product = item["product"]
                    variant = item["variant"]
                    quantity = item["quantity"]

                    OrderItem.objects.create(
                        order=order,
                        product=product,
                        product_name=product.name,
                        product_price=item["price"],
                        quantity=quantity,
                        size=item["size"],
                        color=item["color"],
                        product_type=(
                            product.category.product_type
                            if product.category_id
                            else ""
                        ),
                    )

                    if variant:
                        variant.stock -= quantity
                        variant.save(update_fields=["stock"])

                        # Keep aggregate product stock synchronized.
                        product.stock = sum(
                            ProductVariant.objects.filter(
                                product=product
                            ).values_list("stock", flat=True)
                        )
                        product.save(update_fields=["stock"])
                    else:
                        product.stock -= quantity
                        product.save(update_fields=["stock"])

                return Response(
                    self.get_serializer(order).data,
                    status=status.HTTP_201_CREATED,
                )

        except Exception:
            # Log the exception server-side before returning a generic
            # error in production; never expose sensitive details.
            return Response(
                {"error": "Unable to process the order. Please contact support."},
                status=status.HTTP_400_BAD_REQUEST,
            )


class OrderDetailView(generics.RetrieveAPIView):
    serializer_class = OrderSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_serializer_context(self):
        context = super().get_serializer_context()
        context["request"] = self.request
        return context

    def get_queryset(self):
        return Order.objects.filter(user=self.request.user)