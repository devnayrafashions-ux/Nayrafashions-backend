
import logging
from decimal import Decimal

import razorpay

from django.conf import settings
from django.db import transaction
from django.db.models import Sum

from rest_framework import permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView

from orders.models import Order, OrderItem
from orders.utils import send_order_confirmation_email
from store.models import Product, ProductVariant
from .models import Payment

logger = logging.getLogger(__name__)

FREE_SHIPPING_THRESHOLD = Decimal("2999.00")
SHIPPING_FEE = Decimal("99.00")


def get_razorpay_client():
    return razorpay.Client(
        auth=(
            settings.RAZORPAY_KEY_ID,
            settings.RAZORPAY_KEY_SECRET,
        )
    )


def calculate_shipping(subtotal):
    return (
        Decimal("0.00")
        if subtotal >= FREE_SHIPPING_THRESHOLD
        else SHIPPING_FEE
    )


class CreatePaymentView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        data = request.data
        items = data.get("items")

        required_fields = [
            "full_name",
            "email",
            "phone",
            "address_line1",
            "city",
            "state",
            "pincode",
        ]

        for field in required_fields:
            if not str(data.get(field, "")).strip():
                return Response(
                    {
                        "error": (
                            f"{field.replace('_', ' ').title()} "
                            "is required."
                        )
                    },
                    status=status.HTTP_400_BAD_REQUEST,
                )

        if not isinstance(items, list) or not items:
            return Response(
                {"error": "Your cart is empty."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        try:
            with transaction.atomic():
                validated_items = []
                subtotal = Decimal("0.00")

                for item in items:
                    product_id = item.get("product_id")
                    variant_id = item.get("variant_id")
                    size = str(item.get("size", "")).strip()
                    color = str(item.get("color", "")).strip()

                    try:
                        quantity = int(item.get("quantity", 1))
                        if quantity < 1:
                            raise ValueError
                    except (ValueError, TypeError):
                        return Response(
                            {"error": "Invalid item quantity."},
                            status=status.HTTP_400_BAD_REQUEST,
                        )

                    product = Product.objects.filter(
                        id=product_id,
                        is_active=True,
                    ).first()

                    if not product:
                        return Response(
                            {"error": "A product is unavailable."},
                            status=status.HTTP_400_BAD_REQUEST,
                        )

                    variant = None

                    if variant_id:
                        variant = ProductVariant.objects.filter(
                            id=variant_id,
                            product=product,
                        ).first()
                    elif size:
                        variant = ProductVariant.objects.filter(
                            product=product,
                            size=size,
                            color=color,
                        ).first()

                    if product.variants.exists():
                        if not variant:
                            return Response(
                                {
                                    "error": (
                                        f"Please select a valid size "
                                        f"for {product.name}."
                                    )
                                },
                                status=status.HTTP_400_BAD_REQUEST,
                            )

                        if variant.stock < quantity:
                            return Response(
                                {
                                    "error": (
                                        f"Only {variant.stock} item(s) "
                                        f"remain for {product.name}, "
                                        f"size {variant.size}."
                                    )
                                },
                                status=status.HTTP_400_BAD_REQUEST,
                            )

                        size = variant.size
                        color = variant.color or color

                    elif product.stock < quantity:
                        return Response(
                            {
                                "error": (
                                    f"Insufficient stock for "
                                    f"{product.name}."
                                )
                            },
                            status=status.HTTP_400_BAD_REQUEST,
                        )

                    price = Decimal(str(product.price))
                    subtotal += price * quantity

                    validated_items.append({
                        "product": product,
                        "variant": variant,
                        "quantity": quantity,
                        "price": price,
                        "size": size,
                        "color": color,
                    })

                shipping = calculate_shipping(subtotal)
                total = subtotal + shipping
                amount_paise = int(total * 100)

                # Create the Razorpay order using the server-calculated
                # total, never an amount supplied by the frontend.
                rz_order = get_razorpay_client().order.create({
                    "amount": amount_paise,
                    "currency": "INR",
                    "receipt": (
                        f"u{request.user.id}-"
                        f"{Order.objects.count()}"
                    ),
                })

                order = Order.objects.create(
                    user=request.user,
                    status="pending",
                    full_name=data["full_name"].strip(),
                    email=data["email"].strip(),
                    phone=data["phone"].strip(),
                    address_line1=data["address_line1"].strip(),
                    address_line2=data.get(
                        "address_line2", ""
                    ).strip(),
                    city=data["city"].strip(),
                    state=data["state"].strip(),
                    pincode=data["pincode"].strip(),
                    notes=data.get("notes", "").strip(),
                    subtotal=subtotal,
                    shipping_charge=shipping,
                    total=total,
                    razorpay_order_id=rz_order["id"],
                )

                # Save server-validated item names, prices and quantities.
                # Stock is deducted only after payment verification.
                for item in validated_items:
                    product = item["product"]

                    OrderItem.objects.create(
                        order=order,
                        product=product,
                        product_name=product.name,
                        product_price=item["price"],
                        quantity=item["quantity"],
                        size=item["size"],
                        color=item["color"],
                        product_type=(
                            product.category.product_type
                            if product.category_id
                            else ""
                        ),
                    )

                Payment.objects.create(
                    order=order,
                    razorpay_order_id=rz_order["id"],
                    amount=total,
                    status="created",
                )

                return Response(
                    {
                        "order_id": order.id,
                        "order_number": order.order_number,
                        "razorpay_order_id": rz_order["id"],
                        "amount": amount_paise,
                        "currency": "INR",
                        "key": settings.RAZORPAY_KEY_ID,
                        "subtotal": str(subtotal),
                        "shipping_charge": str(shipping),
                        "total": str(total),
                    },
                    status=status.HTTP_201_CREATED,
                )

        except Exception:
            logger.exception("Failed to create checkout order")
            return Response(
                {
                    "error": (
                        "Unable to create your order. Please try again."
                    )
                },
                status=status.HTTP_400_BAD_REQUEST,
            )


class VerifyPaymentView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        payment_id = request.data.get("razorpay_payment_id")
        razorpay_order_id = request.data.get("razorpay_order_id")
        signature = request.data.get("razorpay_signature")

        if not all([payment_id, razorpay_order_id, signature]):
            return Response(
                {"error": "Missing Razorpay payment details."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        client = get_razorpay_client()

        # Verify the Razorpay signature and fetch the payment status.
        try:
            client.utility.verify_payment_signature({
                "razorpay_order_id": razorpay_order_id,
                "razorpay_payment_id": payment_id,
                "razorpay_signature": signature,
            })

            razorpay_payment = client.payment.fetch(payment_id)

        except Exception:
            logger.warning(
                "Razorpay verification failed for order %s",
                razorpay_order_id,
            )
            return Response(
                {"error": "Payment signature verification failed."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        if razorpay_payment.get("order_id") != razorpay_order_id:
            return Response(
                {"error": "Payment does not match this order."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        if razorpay_payment.get("status") != "captured":
            return Response(
                {"error": "Payment has not been captured yet."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        # A different order must never be processed using this payment ID.
        existing_payment = Payment.objects.filter(
            razorpay_payment_id=payment_id
        ).exclude(razorpay_order_id=razorpay_order_id).exists()

        if existing_payment:
            return Response(
                {"error": "This payment has already been used."},
                status=status.HTTP_409_CONFLICT,
            )

        try:
            with transaction.atomic():
                order = Order.objects.select_for_update().filter(
                    user=request.user,
                    razorpay_order_id=razorpay_order_id,
                ).first()

                if not order:
                    return Response(
                        {"error": "Order not found."},
                        status=status.HTTP_404_NOT_FOUND,
                    )

                payment = Payment.objects.select_for_update().filter(
                    order=order,
                    razorpay_order_id=razorpay_order_id,
                ).first()

                if not payment:
                    return Response(
                        {"error": "Payment record not found."},
                        status=status.HTTP_404_NOT_FOUND,
                    )

                # Idempotency: don't deduct stock or send another email
                # when the same successfully processed payment is retried.
                if payment.status == "paid" and order.status != "pending":
                    return Response({
                        "status": "Payment already verified.",
                        "order_id": order.id,
                        "order_number": order.order_number,
                    })

                if order.status != "pending":
                    return Response(
                        {"error": "This order cannot be processed again."},
                        status=status.HTTP_409_CONFLICT,
                    )

                expected_amount = int(order.total * 100)

                if (
                    int(razorpay_payment.get("amount", -1))
                    != expected_amount
                    or payment.amount != order.total
                ):
                    return Response(
                        {
                            "error": (
                                "Paid amount does not match "
                                "the order total."
                            )
                        },
                        status=status.HTTP_400_BAD_REQUEST,
                    )

                order_items = list(
                    order.items.select_related("product").all()
                )

                locked_variants = {}
                locked_products = {}

                # Validate every inventory item before deducting any stock.
                for item in order_items:
                    if not item.product_id:
                        return Response(
                            {
                                "error": (
                                    f"{item.product_name} is unavailable."
                                )
                            },
                            status=status.HTTP_409_CONFLICT,
                        )

                    product = Product.objects.select_for_update().filter(
                        id=item.product_id,
                    ).first()

                    if not product:
                        return Response(
                            {
                                "error": (
                                    f"{item.product_name} is unavailable."
                                )
                            },
                            status=status.HTTP_409_CONFLICT,
                        )

                    locked_products[product.id] = product

                    if product.variants.exists():
                        variant = ProductVariant.objects.select_for_update().filter(
                            product=product,
                            size=item.size,
                            color=item.color,
                        ).first()

                        if not variant:
                            return Response(
                                {
                                    "error": (
                                        f"Inventory variant unavailable "
                                        f"for {item.product_name}, "
                                        f"size {item.size}."
                                    )
                                },
                                status=status.HTTP_409_CONFLICT,
                            )

                        if variant.stock < item.quantity:
                            return Response(
                                {
                                    "error": (
                                        "Payment was received, but stock "
                                        "has changed. Contact support "
                                        "for a refund."
                                    ),
                                    "payment_id": payment_id,
                                    "order_number": order.order_number,
                                },
                                status=status.HTTP_409_CONFLICT,
                            )

                        locked_variants[item.id] = variant

                    elif product.stock < item.quantity:
                        return Response(
                            {
                                "error": (
                                    "Payment was received, but stock "
                                    "has changed. Contact support "
                                    "for a refund."
                                ),
                                "payment_id": payment_id,
                                "order_number": order.order_number,
                            },
                            status=status.HTTP_409_CONFLICT,
                        )

                # Deduct inventory after all checks pass.
                for item in order_items:
                    product = locked_products[item.product_id]
                    variant = locked_variants.get(item.id)

                    if variant:
                        variant.stock -= item.quantity
                        variant.save(update_fields=["stock"])

                        total_stock = (
                            ProductVariant.objects.filter(
                                product=product
                            ).aggregate(total=Sum("stock"))["total"] or 0
                        )
                        product.stock = total_stock
                    else:
                        product.stock -= item.quantity

                    product.save(update_fields=["stock"])

                payment.razorpay_payment_id = payment_id
                payment.razorpay_signature = signature
                payment.status = "paid"
                payment.save(update_fields=[
                    "razorpay_payment_id",
                    "razorpay_signature",
                    "status",
                ])

                order.status = "confirmed"
                order.save(update_fields=["status", "updated_at"])

                # Send the order confirmation only after the transaction
                # commits successfully. Email errors must not undo payment.
                transaction.on_commit(
                    lambda order_id=order.id: _send_order_email(order_id)
                )

                return Response({
                    "status": "Payment verified successfully.",
                    "order_id": order.id,
                    "order_number": order.order_number,
                })

        except Exception:
            logger.exception(
                "Error processing verified payment %s",
                payment_id,
            )
            return Response(
                {
                    "error": (
                        "Payment was received, but order processing needs "
                        "attention. Contact support with your payment ID."
                    ),
                    "payment_id": payment_id,
                },
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )


def _send_order_email(order_id):
    """
    Load the committed order and send the confirmation email.
    The email helper handles and logs sending failures.
    """
    try:
        order = Order.objects.get(id=order_id)
        send_order_confirmation_email(order)
    except Exception:
        logger.exception(
            "Could not send order confirmation email for order %s",
            order_id,
        )
